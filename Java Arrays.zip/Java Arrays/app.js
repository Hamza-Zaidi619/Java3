// var name1 = "hamza";
// var name2= "haider";
// var name3 = "ali";
// console.log(name1);   // strings ke ilawa we can use number here to//


// [ARRAYS]
// var students = ["hamza", "haider", "ali"];
// console.log( "welcome " + students[2]);


// EMPTY ARRAYS
// var marks= [];
// marks[0]= 78;
// marks[1]= 90;
// console.log(marks);
// console.log(marks[1]);

// var names=[];
// names[0]= "hamza";
// names[1]= "haider";
// // console.log(names);
// console.log(names[0]);

// adding and removing at end

// var students = ["hamza", "haider", "ali"];
// students.pop(); // removes value at end
// students.push("brock","Bajwa");  // adds a value at end
// console.log( students);


// adding an removing at start
//  var students=["hamza","haider","ali"];
// students.shift(); //removes value at start
// students.unshift("bajwa","shafiq"); // add value at start
// console.log(students);


// splice add or remove in between
// var students=["hamza","haider","ali","farhan"];
// // students.splice(1,1,"bilal"); 
// students.splice(1,2);
// console.log(students);


// slice
// var students=["ali","hamza","farhan","haider","bajwa"];
// console.log(students);
// var copy = students.slice(2,5);
// console.log(copy);


// FOR LOOP
/*SYNTAX:- for(initialisation;condition;updation){
     do something
     initialisation(var a =1)
     condition(a <=5)
     updation(a=a+1)
}*/

// table
// for(var i=1; i<=10; i++){
//     console.log( "2"+"x"+ i + "=" + 2*i);
// }


// var names = ["hamza","haider","ali"];
// for(var i =0; i< names.length; i++){
//     console.log(names[i]);
// }


// var marks=[90,98,70,65];
// for(var i=0; i<marks.length; i++){
//     console.log(marks[i]);
// }


// Flags
// var cities = ["London", "newyork", "Jeddah", "Karachi"];
// for (var i = 0; i < cities.length; i++){
//     // console.log(cities[i]);
//     if (cities[i] ==="newyork"){
//         alert(cities[i] + " is cleanest city!")
//         break;
//     }
// }

//infinite loop
// for(var i=1; i>0; i++){
//     console.log("hello");
// }


// stopping infinite loop
// for(var i=1; i>0; i++){
//     if(i==10){
//         break
//     }
//     console.log("hello")
// }

// Break

// for(var i=0; i<10;i++){
//     if(i==5){
//         break;
//     }
//     console.log("welcome")
// }


